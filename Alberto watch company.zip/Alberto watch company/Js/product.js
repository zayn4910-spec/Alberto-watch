// navbar

// MOBILE MENU
function toggleMenu() {
    document.getElementById("navLinks").classList.toggle("active");
}

// DROPDOWN MENU
function toggleDropdown() {
    document.getElementById("dropdownMenu").classList.toggle("show");
}

// navbar ends

// cards code start


let selectedWatch = "";
let cartItems = 0;


// OPEN WATCH DETAILS

function viewDetails(name, image, price, description) {

    selectedWatch = name;

    document.getElementById("modalTitle").innerText = name;

    document.getElementById("modalDescription").innerText = description;

    document.getElementById("modalPrice").innerText = price;

    document.getElementById("modalBackground").style.backgroundImage =
        "url('" + image + "')";

    document.getElementById("watchModal").classList.add("show");

}


// CLOSE POPUP

function closeDetails() {

    document.getElementById("watchModal").classList.remove("show");

}


// ADD TO CART

function addToCart() {

    cartItems++;

    let cartCount = document.getElementById("cartCount");

    if (cartCount) {
        cartCount.innerText = cartItems;
    }

    alert(selectedWatch + " added to your cart!");

}


// BUY NOW

function buyNow() {

    alert("You selected " + selectedWatch +
    "! Thank you for shopping with Alberto Watch Company.");

}


// CLICK OUTSIDE TO CLOSE

document.getElementById("watchModal").addEventListener("click", function(event) {

    if (event.target === this) {
        closeDetails();
    }

});


// ESCAPE KEY TO CLOSE

document.addEventListener("keydown", function(event) {

    if (event.key === "Escape") {
        closeDetails();
    }

});


// card code ends