// navbar

// MOBILE MENU
function toggleMenu() {
    document.getElementById("navLinks").classList.toggle("active");
}

// DROPDOWN MENU
function toggleDropdown() {
    document.getElementById("dropdownMenu").classList.toggle("show");
}

// navbar ends