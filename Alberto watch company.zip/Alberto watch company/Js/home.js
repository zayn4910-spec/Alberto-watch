
// OPEN AND CLOSE MOBILE MENU
function toggleMenu() {

    let menu = document.getElementById("navLinks");

    menu.classList.toggle("show");

}


// OPEN AND CLOSE DROPDOWN
function toggleDropdown() {

    let dropdown = document.getElementById("dropdownMenu");

    dropdown.classList.toggle("show");

}

// carousel code


// GET ALL WATCH SLIDES
let slides = document.querySelectorAll(".watch-slide");

// STARTING SLIDE
let currentSlide = 0;

// FUNCTION TO CHANGE SLIDES
function changeSlide(direction) {

    // REMOVE ACTIVE CLASS
    slides[currentSlide].classList.remove("active");

    // CHANGE SLIDE
    currentSlide = currentSlide + direction;

    // CHECK FIRST AND LAST SLIDES
    if (currentSlide >= slides.length) {
        currentSlide = 0;
    }

    if (currentSlide < 0) {
        currentSlide = slides.length - 1;
    }

    // SHOW NEW SLIDE
    slides[currentSlide].classList.add("active");
}

// AUTOMATIC SLIDING EVERY 4 SECONDS
setInterval(function() {
    changeSlide(1);
}, 4000);


// carousel code end
